# Heart Disease Prediction using Machine Learning

## Overview
This project predicts the presence of heart disease using a dataset from Cleveland, Hungary, Long Beach, and Switzerland. A Random Forest model is trained and deployed via a Flask web app.

## Features
- 14 clinical features
- Trained with Random Forest Classifier
- Web form for user input and prediction
- Handles missing values

## Tools
- Python 3.7
- Pandas
- NumPy
- Flask
- scikit-learn

## How to Run
1. Place the dataset `heart.csv` in the root folder.
2. Run `train_model.py` to train and save the model.
3. Run `app.py` to start the Flask app.
4. Open `http://127.0.0.1:5000` in your browser.

## Dataset Format
Make sure your dataset has the 14 standard features, and the target is labeled as `target` with values 0 (no disease) and 1+ (disease).
